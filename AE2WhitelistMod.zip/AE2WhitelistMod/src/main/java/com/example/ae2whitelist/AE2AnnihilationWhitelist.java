package com.example.ae2whitelist;

public class AE2AnnihilationWhitelist {
    public static void main(String[] args) {
        System.out.println("AE2 whitelist mod placeholder");
    }
}